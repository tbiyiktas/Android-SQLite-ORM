// lib/persistence/GenericRepository.java
package lib.persistence;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.stream.Collectors;

import lib.persistence.command.manipulation.InsertCommand;
import lib.persistence.command.manipulation.UpdateCommand;
import lib.persistence.command.query.Select;
import lib.persistence.command.query.SelectQuery;
import lib.persistence.profile.DbColumn;
import lib.persistence.profile.Mapper;

public abstract class GenericRepository<T> {
    protected final DbContext dbContext;
    protected final Class<T> type;

    protected GenericRepository(DbContext ctx, Class<T> type) {
        this.dbContext = ctx;
        this.type = type;
    }

    // CREATE
    public void insert(T entity, DbCallback<T> cb) {
        dbContext.runDbOperation(db -> {
            InsertCommand cmd = InsertCommand.build(entity);
            long rowId = db.insert(cmd.getTableName(), null, cmd.getContentValues());
            if (rowId == -1) throw new Exception("Insert failed");
            return new DbResult.Success<>(entity);
        }, cb, true);
    }

    // UPDATE (PK’lere göre)
    public void update(T entity, DbCallback<T> cb) {
        dbContext.runDbOperation(db -> {
            UpdateCommand cmd = UpdateCommand.build(entity);
            int n = db.update(cmd.getTableName(), cmd.getValues(), cmd.getWhereClause(), cmd.getWhereArgs());
            if (n <= 0) throw new Exception("Update affected 0 rows");
            return new DbResult.Success<>(entity);
        }, cb, true);
    }

    // DELETE (entity’nin PK değeriyle)
    public void delete(T entity, DbCallback<T> cb) {
        dbContext.runDbOperation(db -> {
            String table = Mapper.getTableName(type);
            ArrayList<DbColumn> cols = Mapper.classToDbColumns(type);
            ArrayList<DbColumn> pks = new ArrayList<>();
            for (DbColumn c : cols) if (c.isPrimaryKey()) pks.add(c);
            if (pks.isEmpty()) throw new Exception("No primary key");

            String where = pks.stream().map(c -> c.getColumnName() + " = ?").collect(Collectors.joining(" AND "));
            String[] args = new String[pks.size()];
            for (int i = 0; i < pks.size(); i++) {
                Field f = type.getDeclaredField(pks.get(i).getFieldName());
                f.setAccessible(true);
                Object v = f.get(entity);
                args[i] = v == null ? null : String.valueOf(v);
            }
            int n = db.delete(table, where, args);
            if (n <= 0) throw new Exception("Delete affected 0 rows");
            return new DbResult.Success<>(entity);
        }, cb, true);
    }

    // READ: getById (tek PK varsayımı; çoklu PK’ler için overload yazılabilir)
    public void getById(Object id, DbCallback<T> cb) {
        dbContext.runDbOperation(db -> {
            ArrayList<DbColumn> cols = Mapper.classToDbColumns(type);
            DbColumn pk = cols.stream().filter(DbColumn::isPrimaryKey).findFirst()
                    .orElseThrow(() -> new Exception("No primary key"));
            String sql = "SELECT * FROM " + Mapper.getTableName(type) + " WHERE " + pk.getColumnName() + " = ? LIMIT 1";
            try (Cursor c = db.rawQuery(sql, new String[]{ String.valueOf(id) })) {
                if (c.moveToFirst()) {
                    T obj = Mapper.cursorToObject(c, type);
                    return new DbResult.Success<>(obj);
                } else {
                    return new DbResult.Success<>(null); // bulunamadı
                }
            }
        }, cb, false);
    }

    // READ: hepsi
    public void selectAll(DbCallback<ArrayList<T>> cb) {
        selectWith(Select.from(type), cb);
    }

    // READ: Select builder ile
    public void selectWith(Select<T> builder, DbCallback<ArrayList<T>> cb) {
        SelectQuery<T> q = builder.compile();
        dbContext.runDbOperation(db -> {
            ArrayList<T> list = new ArrayList<>();
            try (Cursor c = db.rawQuery(q.getSql(), q.getArgs())) {
                while (c.moveToNext()) list.add(q.getRowMapperOrDefault().apply(c));
            }
            return new DbResult.Success<>(list);
        }, cb, false);
    }

    // İsteğe bağlı: ham sorgu (örnekteki gibi)
    public void rawQuery(String sql, String[] args, DbCallback<ArrayList<java.util.HashMap<String,String>>> cb) {
        dbContext.runDbOperation(db -> {
            ArrayList<java.util.HashMap<String,String>> rows = new ArrayList<>();
            try (Cursor c = db.rawQuery(sql, args)) {
                String[] names = c.getColumnNames();
                while (c.moveToNext()) {
                    java.util.HashMap<String,String> row = new java.util.HashMap<>();
                    for (String col : names) {
                        int idx = c.getColumnIndex(col);
                        row.put(col, c.isNull(idx) ? null : c.getString(idx));
                    }
                    rows.add(row);
                }
            }
            return new DbResult.Success<>(rows);
        }, cb, false);
    }
}

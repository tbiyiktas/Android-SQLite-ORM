package lib.persistence.command.manipulation;


import android.content.ContentValues;
import lib.persistence.profile.DbColumn;
import lib.persistence.profile.Mapper;


import java.util.ArrayList;
import java.util.stream.Collectors;


public class UpdateCommand {
    private final String tableName;
    private final ContentValues values;
    private final String whereClause;
    private final String[] whereArgs;


    private UpdateCommand(String tableName, ContentValues values, String whereClause, String[] whereArgs) {
        this.tableName = tableName; this.values = values; this.whereClause = whereClause; this.whereArgs = whereArgs;
    }


    public static UpdateCommand build(Object entity) {
        Class<?> type = entity.getClass();
        String table = Mapper.getTableName(type);
        ArrayList<DbColumn> cols = Mapper.classToDbColumns(type);


// PK kolonu(ları)
        ArrayList<DbColumn> pks = new ArrayList<>();
        for (DbColumn c : cols) if (c.isPrimaryKey()) pks.add(c);
        if (pks.isEmpty()) throw new IllegalStateException("Update için en az bir PK gerekir");


        ContentValues cv = Mapper.objectToContentValues(entity);


        String where = pks.stream().map(c -> c.getColumnName() + " = ?").collect(Collectors.joining(" AND "));
        String[] args = new String[pks.size()];
        try {
            for (int i = 0; i < pks.size(); i++) {
                java.lang.reflect.Field f = entity.getClass().getDeclaredField(pks.get(i).getFieldName());
                f.setAccessible(true);
                Object v = f.get(entity);
                args[i] = v == null ? null : String.valueOf(v);
            }
        } catch (Exception e) { throw new RuntimeException(e); }


        return new UpdateCommand(table, cv, where, args);
    }


    public String getTableName() { return tableName; }
    public ContentValues getValues() { return values; }
    public String getWhereClause() { return whereClause; }
    public String[] getWhereArgs() { return whereArgs; }
}
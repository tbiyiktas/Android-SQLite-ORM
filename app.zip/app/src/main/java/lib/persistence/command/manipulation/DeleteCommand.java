package lib.persistence.command.manipulation;

import lib.persistence.profile.DbColumn;
import lib.persistence.profile.Mapper;

import java.lang.reflect.Field;
import java.util.ArrayList;

public class DeleteCommand {

    private final String tableName;
    private final String whereClause;   // null → tüm satırlar
    private final String[] whereArgs;   // null → arg yok

    private DeleteCommand(String tableName, String whereClause, String[] whereArgs) {
        this.tableName = tableName;
        this.whereClause = whereClause;
        this.whereArgs = whereArgs;
    }

    /** Entity örneğinden, ilk PK alanına göre DELETE komutu oluşturur. */
    public static DeleteCommand build(Object entity) {
        if (entity == null) throw new IllegalArgumentException("entity boş olamaz");

        Class<?> type = entity.getClass();
        String table = Mapper.getTableName(type);

        // İlk PK kolonu bulunur
        ArrayList<DbColumn> cols = Mapper.classToDbColumns(type);
        DbColumn pk = null;
        for (DbColumn c : cols) { if (c.isPrimaryKey()) { pk = c; break; } }
        if (pk == null) throw new IllegalStateException("Primary key bulunamadı: " + type.getName());

        // PK değeri okunur
        Object pkValue;
        try {
            Field f = findField(type, pk.getFieldName());
            f.setAccessible(true);
            pkValue = f.get(entity);
        } catch (Exception e) {
            throw new RuntimeException("PK değeri okunamadı: " + pk.getFieldName(), e);
        }
        if (pkValue == null) throw new IllegalStateException("PK değeri null olamaz");

        return new DeleteCommand(
                table,
                pk.getColumnName() + " = ?",
                new String[]{ String.valueOf(pkValue) }
        );
    }

    /** Tip + PK değeri ile DELETE komutu. */
    public static DeleteCommand build(Class<?> type, Object primaryKeyValue) {
        if (type == null) throw new IllegalArgumentException("type boş olamaz");
        if (primaryKeyValue == null) throw new IllegalArgumentException("primaryKeyValue boş olamaz");

        String table = Mapper.getTableName(type);

        ArrayList<DbColumn> cols = Mapper.classToDbColumns(type);
        DbColumn pk = null;
        for (DbColumn c : cols) { if (c.isPrimaryKey()) { pk = c; break; } }
        if (pk == null) throw new IllegalStateException("Primary key bulunamadı: " + type.getName());

        return new DeleteCommand(
                table,
                pk.getColumnName() + " = ?",
                new String[]{ String.valueOf(primaryKeyValue) }
        );
    }

    /** Tüm satırlar için DELETE (where yok). Dikkatli kullanın. */
    public static DeleteCommand buildAll(Class<?> type) {
        if (type == null) throw new IllegalArgumentException("type boş olamaz");
        return new DeleteCommand(Mapper.getTableName(type), null, null);
    }

    private static Field findField(Class<?> type, String name) throws NoSuchFieldException {
        Class<?> cur = type;
        while (cur != null && cur != Object.class) {
            try { return cur.getDeclaredField(name); } catch (NoSuchFieldException ignore) {}
            cur = cur.getSuperclass();
        }
        throw new NoSuchFieldException(name);
    }

    public String getTableName() { return tableName; }
    public String getWhereClause() { return whereClause; }
    public String[] getWhereArgs() { return whereArgs; }
}
